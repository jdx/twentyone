module FriendHelper
end
