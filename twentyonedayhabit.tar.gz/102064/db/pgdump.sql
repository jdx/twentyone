--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: habit_days; Type: TABLE; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

CREATE TABLE habit_days (
    id integer NOT NULL,
    habit_id integer,
    date date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.habit_days OWNER TO hnbmecnriq;

--
-- Name: habit_days_id_seq; Type: SEQUENCE; Schema: public; Owner: hnbmecnriq
--

CREATE SEQUENCE habit_days_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.habit_days_id_seq OWNER TO hnbmecnriq;

--
-- Name: habit_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hnbmecnriq
--

ALTER SEQUENCE habit_days_id_seq OWNED BY habit_days.id;


--
-- Name: habit_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hnbmecnriq
--

SELECT pg_catalog.setval('habit_days_id_seq', 8, true);


--
-- Name: habits; Type: TABLE; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

CREATE TABLE habits (
    id integer NOT NULL,
    user_id integer,
    start_date date,
    what character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.habits OWNER TO hnbmecnriq;

--
-- Name: habits_id_seq; Type: SEQUENCE; Schema: public; Owner: hnbmecnriq
--

CREATE SEQUENCE habits_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.habits_id_seq OWNER TO hnbmecnriq;

--
-- Name: habits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hnbmecnriq
--

ALTER SEQUENCE habits_id_seq OWNED BY habits.id;


--
-- Name: habits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hnbmecnriq
--

SELECT pg_catalog.setval('habits_id_seq', 7, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO hnbmecnriq;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    facebook_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    admin boolean,
    facebook_identifier character varying(255)
);


ALTER TABLE public.users OWNER TO hnbmecnriq;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: hnbmecnriq
--

CREATE SEQUENCE users_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO hnbmecnriq;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hnbmecnriq
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hnbmecnriq
--

SELECT pg_catalog.setval('users_id_seq', 6, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hnbmecnriq
--

ALTER TABLE habit_days ALTER COLUMN id SET DEFAULT nextval('habit_days_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hnbmecnriq
--

ALTER TABLE habits ALTER COLUMN id SET DEFAULT nextval('habits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hnbmecnriq
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: habit_days; Type: TABLE DATA; Schema: public; Owner: hnbmecnriq
--

COPY habit_days (id, habit_id, date, created_at, updated_at) FROM stdin;
2	3	2010-11-14	2010-11-15 07:06:03.180238	2010-11-15 07:06:03.180238
7	5	2010-11-14	2010-11-15 07:54:48.088681	2010-11-15 07:54:48.088681
\.


--
-- Data for Name: habits; Type: TABLE DATA; Schema: public; Owner: hnbmecnriq
--

COPY habits (id, user_id, start_date, what, created_at, updated_at) FROM stdin;
3	2	2010-11-14	Drink a liter of water in the morning.	2010-11-15 07:06:01.41443	2010-11-15 07:06:01.41443
5	1	2010-11-14	Read at least 1 chapter of a book.	2010-11-15 07:20:46.280731	2010-11-15 07:20:46.280731
6	5	2010-11-16	work out	2010-11-15 07:35:10.677141	2010-11-15 07:35:10.677141
7	6	2010-11-15	reading 30 Minutes a day	2010-11-15 07:50:14.044321	2010-11-15 07:50:14.044321
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: hnbmecnriq
--

COPY schema_migrations (version) FROM stdin;
20101114042409
20101114085846
20101114090338
20101115035635
20101115053015
20101115054135
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hnbmecnriq
--

COPY users (id, first_name, last_name, facebook_id, created_at, updated_at, admin, facebook_identifier) FROM stdin;
2	Ruby	Rail	100001841527886	2010-11-15 06:58:13.418929	2010-11-15 06:58:13.418929	\N	100001841527886
1	Jeff	Dickey	42004440	2010-11-15 06:57:53.358781	2010-11-15 07:11:11.690953	t	42004440
3	Jon	Blackwell	6206852	2010-11-15 07:18:39.312274	2010-11-15 07:18:39.312274	\N	6206852
4	Dorothy	Goodnight	638239250	2010-11-15 07:32:47.087804	2010-11-15 07:32:47.087804	\N	638239250
5	Grant	Dunigan	509702776	2010-11-15 07:34:41.918993	2010-11-15 07:34:41.918993	\N	509702776
6	Robert	Cummings	1065808179	2010-11-15 07:49:01.863482	2010-11-15 07:49:01.863482	\N	1065808179
\.


--
-- Name: habit_days_pkey; Type: CONSTRAINT; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

ALTER TABLE ONLY habit_days
    ADD CONSTRAINT habit_days_pkey PRIMARY KEY (id);


--
-- Name: habits_pkey; Type: CONSTRAINT; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

ALTER TABLE ONLY habits
    ADD CONSTRAINT habits_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: hnbmecnriq; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

