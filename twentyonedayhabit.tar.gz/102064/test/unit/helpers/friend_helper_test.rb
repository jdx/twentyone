require 'test_helper'

class FriendHelperTest < ActionView::TestCase
end
