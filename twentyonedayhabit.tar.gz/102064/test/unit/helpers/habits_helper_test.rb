require 'test_helper'

class HabitsHelperTest < ActionView::TestCase
end
